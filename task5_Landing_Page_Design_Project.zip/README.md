# Landing Page Design (Task5)

Project Topic: Fitness App Landing Page

Goal:
Design a modern landing page with strong visual hierarchy, clear call-to-action buttons, and consistent UI elements.

Deliverables:
- Project Report
- Design Specifications
- Wireframe Description
